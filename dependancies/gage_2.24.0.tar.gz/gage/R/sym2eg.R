sym2eg <- function(sym) return(egSymb[match(sym, egSymb[, 
    2]), 1])
 
