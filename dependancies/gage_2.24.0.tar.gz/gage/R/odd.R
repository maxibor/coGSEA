odd <- function(x) x%%2 == 1
 
