readExpData <- function(file = "arrayData.txt", ...) read.delim(file, 
    header = T, sep = "\t", ...)
 
