eg2sym <- function(eg) return(egSymb[match(eg, egSymb[, 
    1]), 2])
 
