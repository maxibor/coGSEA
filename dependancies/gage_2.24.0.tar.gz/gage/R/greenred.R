greenred <- function(n) colorpanel(n, "green", "black", 
    "red")
 
